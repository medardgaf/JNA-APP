import 'package:flutter/material.dart';

class KlivColors {
  static const Color primary = Color(0xFF246BFD);
  static const Color background = Color(0xFFF7F9FF);
  static const Color accent = Color(0xFF00C49A);
}
